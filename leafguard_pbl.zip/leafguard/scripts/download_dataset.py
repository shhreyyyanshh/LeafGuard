"""Download a sample of the PlantVillage dataset from its public GitHub repo (no account or login needed).
  python scripts/download_dataset.py --per-class 150
Uses GitHub's tree API to list classes (about 40 calls; GitHub allows 60/hour without a login) and raw.githubusercontent.com for the images.
Source: github.com/spMohanty/PlantVillage-Dataset (raw/color). Check that repo's LICENSE before redistributing."""
import argparse, http.client, json, random, sys, time, urllib.error, urllib.parse, urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

REPO = "spMohanty/PlantVillage-Dataset"
OUT = Path(__file__).resolve().parents[1] / "dataset" / "PlantVillage"
UA = {"User-Agent": "leafguard-downloader"}


CACHE = OUT.parent / "_listing_cache.json"


def _load_cache():
    try:
        return json.loads(CACHE.read_text())
    except Exception:
        return {}


def api(path):
    """GET a GitHub tree listing. Retries on flaky connections and caches results on disk so re-runs are cheap."""
    cache = _load_cache()
    if path in cache:
        return cache[path]
    req = urllib.request.Request(f"https://api.github.com/repos/{REPO}{path}", headers={**UA, "Accept": "application/vnd.github+json"})
    last = None
    for attempt in range(6):
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                data = json.loads(r.read())
            cache[path] = data
            CACHE.parent.mkdir(parents=True, exist_ok=True); CACHE.write_text(json.dumps(cache))
            return data
        except urllib.error.HTTPError as e:
            if e.code in (403, 429):
                sys.exit("GitHub's hourly request limit was reached. Wait about an hour, or switch network (e.g. phone hotspot) and run again. Progress is saved.")
            if e.code < 500:
                raise
            last = e
        except (http.client.HTTPException, urllib.error.URLError, TimeoutError, ConnectionError, json.JSONDecodeError) as e:
            last = e
        print(f"  network hiccup ({type(last).__name__}), retrying {attempt + 1}/5...")
        time.sleep(2 * (attempt + 1))
    sys.exit(f"Could not reach GitHub after several tries ({last}). Check your internet, then run again; progress is saved.")


def fetch(url, dest):
    if dest.exists() and dest.stat().st_size > 0:
        return True
    for _ in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30) as r:
                data = r.read()
            dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(data); return True
        except Exception:
            time.sleep(1)
    return False


def find_classes():
    for branch in ("master", "main"):
        try:
            root = api(f"/git/trees/{branch}"); break
        except urllib.error.HTTPError as e:
            if e.code != 404: raise
    else:
        sys.exit("Could not find the dataset repository. It may have moved; see the README for other options.")
    top = {e["path"]: e for e in root["tree"]}
    raw = {e["path"]: e for e in api(f"/git/trees/{top['raw']['sha']}")["tree"]}
    color = api(f"/git/trees/{raw['color']['sha']}")["tree"]
    return branch, [(e["path"], e["sha"]) for e in color if e["type"] == "tree"]


def main(per_class):
    branch, classes = find_classes()
    print(f"Found {len(classes)} classes. Downloading up to {per_class} images each into {OUT}")
    rng, total, failed = random.Random(0), 0, 0
    for name, sha in classes:
        files = sorted(e["path"] for e in api(f"/git/trees/{sha}")["tree"] if e["type"] == "blob" and e["path"].lower().endswith((".jpg", ".jpeg", ".png")))
        pick = rng.sample(files, min(per_class, len(files)))
        urls = [(f"https://raw.githubusercontent.com/{REPO}/{branch}/raw/color/{urllib.parse.quote(name)}/{urllib.parse.quote(f)}", OUT / name / f) for f in pick]
        with ThreadPoolExecutor(12) as ex:
            ok = list(ex.map(lambda a: fetch(*a), urls))
        total += sum(ok); failed += len(ok) - sum(ok)
        print(f"  {name}: {sum(ok)}/{len(pick)}")
    print(f"Done. {total} images downloaded, {failed} failed, {len(classes)} classes.")
    if failed > 0.02 * (total + failed):
        sys.exit("Many images failed to download. Run again to fetch the missing ones; finished files are skipped.")
    if total < 50:
        sys.exit("Too few images downloaded. Check your internet connection and run again.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--per-class", type=int, default=150)
    main(ap.parse_args().per_class)
