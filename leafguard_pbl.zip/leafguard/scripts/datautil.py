"""Torch-free dataset helpers shared by train.py and check_setup.py."""
from pathlib import Path

IMG = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def find_root(p: Path):
    """Descend into nested folders (common in downloaded zips) until we reach the class folders."""
    for _ in range(6):
        subs = [d for d in p.iterdir() if d.is_dir()]
        hit = next((n for n in ("train", "raw", "color") if (p / n).is_dir()), None)
        if hit:
            p = p / hit; continue
        if any(f.suffix.lower() in IMG for d in subs for f in list(d.iterdir())[:5] if f.is_file()):
            return p
        if not subs:
            break
        p = max(subs, key=lambda d: sum(1 for _ in d.iterdir()))
    raise SystemExit(f"Could not find class folders with images under {p}")


def class_folders(root: Path):
    return sorted(d.name for d in root.iterdir() if d.is_dir() and any(f.suffix.lower() in IMG for f in list(d.iterdir())[:5] if f.is_file()))
