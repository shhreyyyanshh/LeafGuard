"""Decide what run.bat / run.sh still needs to do. Exit codes: 0 = ready, 10 = download dataset, 11 = (re)train model.
A PlantVillage download should contain 38 plant/disease classes; fewer than LEAFGUARD_MIN_CLASSES (default 30) means it is incomplete."""
import json, os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent)); sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from datautil import class_folders, find_root
from backend.app import config

data = Path(os.getenv("LEAFGUARD_DATASET", config.ROOT / "dataset"))
MIN = int(os.getenv("LEAFGUARD_MIN_CLASSES", "30"))
try:
    classes = class_folders(find_root(data)) if data.exists() else []
except SystemExit:
    classes = []
crops = {c.split("___")[0] for c in classes}
print(f"Dataset: {len(classes)} classes across {len(crops)} plants")
if len(classes) < MIN:
    print(f"Dataset is incomplete (need at least {MIN} classes). Downloading the rest...")
    sys.exit(10)
meta = config.MODEL_PATH.parent / "meta.json"
trained = json.loads(meta.read_text()).get("n_classes") if meta.exists() else None
if not config.MODEL_PATH.exists() or trained != len(classes):
    print(f"Model missing or trained on {trained} classes, dataset has {len(classes)}. Training...")
    sys.exit(11)
print(f"Ready: model knows all {trained} classes.")
