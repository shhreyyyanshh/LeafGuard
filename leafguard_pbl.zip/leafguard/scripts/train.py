"""Transfer-learning training on an ImageFolder dataset (one sub-folder per class, e.g. PlantVillage).
  python scripts/train.py --data dataset/PlantVillage --epochs 5
  python scripts/train.py --data dataset/PlantVillage --epochs 3 --max-per-class 300   # fast CPU run"""
import argparse, json, os, random, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch, torch.nn as nn
import torchvision.transforms as T
from torch.utils.data import DataLoader, Subset
from torchvision.datasets import ImageFolder
from backend.app import config
from datautil import find_root
from backend.app.model import build_model, head_params

def split(targets, max_pc, seed):
    rng, by = random.Random(seed), {}
    for i, t in enumerate(targets):
        by.setdefault(t, []).append(i)
    tr, va, te = [], [], []
    for idx in by.values():
        rng.shuffle(idx)
        idx = idx[:max_pc] if max_pc else idx
        a, b = int(0.8 * len(idx)), int(0.9 * len(idx))
        tr += idx[:a]; va += idx[a:b]; te += idx[b:]
    return tr, va, te


def run(loader, model, dev, crit, opt=None):
    model.train(opt is not None)
    loss_s = correct = n = 0
    with torch.set_grad_enabled(opt is not None):
        for x, y in loader:
            x, y = x.to(dev), y.to(dev)
            out = model(x); loss = crit(out, y)
            if opt:
                opt.zero_grad(); loss.backward(); opt.step()
            loss_s += loss.item() * len(y); correct += (out.argmax(1) == y).sum().item(); n += len(y)
    return loss_s / n, correct / n


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True); ap.add_argument("--arch", default="mobilenet_v2", choices=["mobilenet_v2", "resnet18"])
    ap.add_argument("--epochs", type=int, default=5); ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--max-per-class", type=int, default=0); ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()
    torch.manual_seed(a.seed)
    root = find_root(Path(a.data)); print("Using dataset folder:", root)
    norm = T.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    tf_tr = T.Compose([T.RandomResizedCrop(224, scale=(0.7, 1)), T.RandomHorizontalFlip(), T.RandomVerticalFlip(), T.RandomRotation(20),
                       T.ColorJitter(0.2, 0.2, 0.2), T.ToTensor(), norm])
    tf_ev = T.Compose([T.Resize(256), T.CenterCrop(224), T.ToTensor(), norm])
    ds_tr, ds_ev = ImageFolder(root, tf_tr), ImageFolder(root, tf_ev)
    tr, va, te = split(ds_tr.targets, a.max_per_class, a.seed)
    print(f"{len(ds_tr.classes)} classes | train {len(tr)} | val {len(va)} | test {len(te)}")
    nw = 0 if os.name == "nt" else 2
    L = lambda ds, idx, sh: DataLoader(Subset(ds, idx), batch_size=a.batch, shuffle=sh, num_workers=nw)
    dl_tr, dl_va = L(ds_tr, tr, True), L(ds_ev, va, False)
    dev = "cuda" if torch.cuda.is_available() else "cpu"; print("device:", dev)
    model = build_model(a.arch, len(ds_tr.classes)).to(dev)
    crit, hist, best = nn.CrossEntropyLoss(label_smoothing=0.05), [], 0.0
    for ep in range(a.epochs):
        frozen = ep == 0  # epoch 1: train only the new head, then fine-tune everything
        for p in model.parameters(): p.requires_grad = not frozen
        for p in head_params(model, a.arch): p.requires_grad = True
        opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=1e-3 if frozen else 3e-4)
        t0 = time.time()
        tl, ta = run(dl_tr, model, dev, crit, opt); vl, vacc = run(dl_va, model, dev, crit)
        hist.append({"epoch": ep + 1, "train_loss": tl, "train_acc": ta, "val_loss": vl, "val_acc": vacc})
        print(f"epoch {ep+1}/{a.epochs}  train acc {ta:.3f}  val acc {vacc:.3f}  ({time.time()-t0:.0f}s)")
        if vacc >= best:
            best = vacc
            config.MODEL_PATH.parent.mkdir(exist_ok=True, parents=True)
            torch.save({"arch": a.arch, "classes": ds_tr.classes, "state_dict": model.state_dict(), "val_acc": round(vacc, 4), "img_size": 224}, config.MODEL_PATH)
    m = config.MODEL_PATH.parent
    (m / "history.json").write_text(json.dumps(hist))
    (m / "split.json").write_text(json.dumps({"root": str(root), "test": [ds_ev.samples[i][0] for i in te], "labels": [ds_ev.samples[i][1] for i in te]}))
    (m / "meta.json").write_text(json.dumps({"n_classes": len(ds_tr.classes), "classes": ds_tr.classes, "arch": a.arch}))
    print(f"Saved best model (val acc {best:.3f}) to {config.MODEL_PATH}")
