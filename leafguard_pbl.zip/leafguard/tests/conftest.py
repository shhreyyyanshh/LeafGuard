import os, sys, tempfile
from pathlib import Path
tmp = Path(tempfile.mkdtemp())
os.environ.update(LEAFGUARD_MODEL=str(tmp / "m.pt"), LEAFGUARD_DB=str(tmp / "t.db"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
