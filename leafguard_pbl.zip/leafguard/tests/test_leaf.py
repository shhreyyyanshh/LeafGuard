"""Leaf detection and heat-map maths. Needs only numpy + Pillow (no torch)."""
import numpy as np
from PIL import Image, ImageDraw
from backend.app import leaf


def synth(bg=(250, 250, 250), size=(400, 300), box=(110, 70, 300, 230), color=(70, 140, 50), noise=6, seed=0):
    rng = np.random.default_rng(seed)
    im = Image.new("RGB", size, bg); d = ImageDraw.Draw(im)
    d.ellipse(box, fill=color); d.ellipse((box[0] + 50, box[1] + 40, box[0] + 80, box[1] + 70), fill=(120, 80, 30))  # a "disease spot"
    a = np.asarray(im, np.float32) + rng.normal(0, noise, (size[1], size[0], 3))
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8)), box


def iou(mask, box, scale):
    gt = np.zeros(mask.shape, bool); gt[int(box[1] * scale):int(box[3] * scale), int(box[0] * scale):int(box[2] * scale)] = True
    return (mask & gt).sum() / (mask | gt).sum()


def test_finds_leaf_on_plain_backgrounds():
    for bg in [(250, 250, 250), (120, 120, 120), (30, 30, 30)]:
        im, box = synth(bg=bg)
        info = leaf.detect(im)
        assert info is not None
        assert info["mask"].shape == (im.height, im.width) and 0.6 < iou(info["mask"] > 0.5, box, 1.0) <= 1.0
        assert info["crop"].size[0] == info["crop"].size[1] and info["mask_crop"].shape == (224, 224)


def test_yellow_leaf_on_white():
    im, _ = synth(color=(225, 215, 110)); assert leaf.detect(im) is not None


def test_no_leaf_returns_none():
    assert leaf.detect(Image.new("RGB", (300, 300), (200, 200, 200))) is None


def test_large_image_is_downscaled():
    im, _ = synth(size=(1600, 1200), box=(440, 280, 1200, 920)); assert max(leaf.detect(im)["base"].size) == 512


def test_heatmap_covers_leaf_only_and_overlay_renders():
    pos = leaf.occlusion_positions(224, 56, 28); assert len(pos) == 49
    mask = np.zeros((224, 224), np.float32); mask[40:190, 30:200] = 1
    drops = [1.0 if (i, j) == (56, 56) else 0.1 for i, j in pos]
    hm = leaf.heat_from_drops(drops, pos, 224, 56, mask)
    assert hm.shape == (224, 224) and 0 <= hm.min() and hm.max() <= 1
    assert hm[:30].max() == 0 and hm[:, :20].max() == 0  # nothing outside the leaf
    assert hm[(mask > 0.5)].min() >= 0 and (hm[(mask > 0.5)] > 0.1).mean() > 0.6  # most of the leaf is shaded, not one blob
    im, _ = synth(); info = leaf.detect(im)
    assert leaf.overlay(info["base"], hm, info).startswith("data:image/png") and leaf.outline(info["base"], info["mask"]).startswith("data:")
    assert leaf.overlay(im, hm, None).startswith("data:image/png")
