"""pytest -q. Model tests use an UNTRAINED network (random head), so they check plumbing, not accuracy."""
import io, os
import numpy as np, pytest
from PIL import Image
from backend.app import advice


def png(size=64):
    b = io.BytesIO(); Image.fromarray(np.random.randint(0, 255, (size, size, 3), np.uint8)).save(b, "PNG"); return b.getvalue()


def test_parse_and_advice():
    r = advice.parse("Corn_(maize)___Common_rust_")
    assert r["crop"] == "Corn" and r["condition"] == "Common rust" and not r["healthy"]
    assert advice.parse("Tomato___healthy")["healthy"] and "No disease" in advice.advise("Tomato___healthy")
    assert "Viral" in advice.advise("Tomato___Tomato_mosaic_virus") and "fungal" in advice.advise("Potato___Early_blight")
    assert advice.advise("Weird___Thing")


@pytest.fixture(scope="module")
def client():
    torch = pytest.importorskip("torch"); pytest.importorskip("fastapi"); pytest.importorskip("httpx")
    from fastapi.testclient import TestClient
    from backend.app import config
    from backend.app.model import build_model
    from backend.app.main import app
    with TestClient(app) as c:
        c.no_model = c.post("/api/predict", files={"file": ("a.png", png(), "image/png")})
        m = build_model("mobilenet_v2", 3, pretrained=False)
        torch.save({"arch": "mobilenet_v2", "classes": ["Tomato___healthy", "Tomato___Early_blight", "Tomato___Leaf_Mold"], "state_dict": m.state_dict(), "val_acc": 0.0}, config.MODEL_PATH)
    with TestClient(app) as c2:  # restart so the lifespan loads the checkpoint
        yield c2


def test_missing_model_gives_503(client):
    assert client.no_model.status_code == 503


def test_health_and_predict(client):
    assert client.get("/api/health").json()["model_loaded"] is True
    r = client.post("/api/predict", files={"file": ("leaf.png", png(), "image/png")})
    assert r.status_code == 200
    d = r.json()
    assert len(d["top"]) == 3 and 0 <= d["confidence"] <= 100 and d["heatmap"].startswith("data:image/png") and d["advice"] and "leaf_found" in d
    assert abs(sum(t["confidence"] for t in d["top"]) - 100) < 1.5
    assert len(client.get("/api/history").json()) == 1 and client.get("/api/analytics").json()["predictions"] == 1
    assert client.delete("/api/history").json()["cleared"]


def test_invalid_uploads(client):
    assert client.post("/api/predict", files={"file": ("a.txt", b"hi", "text/plain")}).status_code == 415
    assert client.post("/api/predict", files={"file": ("a.png", b"notimage", "image/png")}).status_code == 400
    assert client.post("/api/predict", files={"file": ("a.png", b"", "image/png")}).status_code == 400
