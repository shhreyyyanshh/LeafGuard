#!/usr/bin/env bash
set -e; cd "$(dirname "$0")"
python3 -m venv .venv 2>/dev/null || true; source .venv/bin/activate
[ -f .venv/.installed ] || { pip install -r requirements.txt && touch .venv/.installed; }
set +e; python scripts/check_setup.py; rc=$?; set -e
if [ $rc -eq 10 ]; then python scripts/download_dataset.py --per-class 200; rc=11; fi
if [ $rc -eq 11 ]; then python scripts/train.py --data dataset --epochs 4 --max-per-class 300 && python evaluation/evaluate.py; fi
echo "Open http://localhost:8000"; uvicorn backend.app.main:app --port 8000
