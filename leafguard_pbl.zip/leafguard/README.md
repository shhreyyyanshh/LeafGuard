# LeafGuard — Plant Disease Detection (Deep Learning PBL)

Upload a leaf photo → the app names the likely disease, shows confidence, the top-3 alternatives, an automatic **leaf-detection** step and a **whole-leaf scan heat-map** (occlusion sensitivity) showing how much every part of the leaf mattered, and plain-language next steps.

> **Status:** written without internet access. Only the Python syntax and the pure-Python advice logic were checked. Training, the API, the whole-leaf heat-map code, the pytest suite and the web page have **not been run**. Expect to fix small bugs on first run. No accuracy numbers exist until *you* train and evaluate.

## Setup (Windows: double-click `run.bat` after step 2)
1. Install Python 3.10+ (tick *Add to PATH*).
2. **Dataset:** `run.bat` downloads a 150-images-per-class sample of PlantVillage from GitHub automatically (no login; needs internet; run `python scripts/download_dataset.py --per-class 500` for more). Alternatively, use Kaggle (free account):
   - *PlantVillage* (15 classes, ~20k images): kaggle.com/datasets/emmarex/plantdisease, or
   - *New Plant Diseases Dataset* (38 classes, ~87k images): kaggle.com/datasets/vipoooool/new-plant-diseases-dataset
   - Click **Download**, unzip into this project's `dataset/` folder. Nested folders are fine; the trainer finds the class folders itself.
   - Original PlantVillage data: Hughes & Salathé 2015 (CC0 on the public release). Check the licence on the Kaggle page you use.
3. `run.bat` (or `./run.sh`) installs packages, trains (3 epochs, 300 images/class: a quick CPU run), evaluates, and opens http://localhost:8000.

Manual / better accuracy:
```
pip install -r requirements.txt
python scripts/train.py --data dataset --epochs 8            # all images; use a GPU if you can
python evaluation/evaluate.py
pytest -q
uvicorn backend.app.main:app --port 8000
```

## Architecture
```
frontend/index.html --REST--> FastAPI backend/app/main.py
                                 |- model.py   MobileNetV2 or ResNet18 (ImageNet-pretrained, new head), prediction + whole-leaf scan
                                 |- advice.py  class name -> crop, condition, advice text
                                 '- store.py   SQLite scan history + stats
scripts/train.py -> models/leafguard.pt (+history.json, split.json) -> evaluation/evaluate.py -> evaluation/results.json, confusion_matrix.png
```
**Training:** per-class 80/10/10 train/val/test split with a fixed seed; epoch 1 trains only the new head, later epochs fine-tune everything (AdamW, label smoothing 0.05); augmentation = random crop, flips, rotation, colour jitter; best-validation checkpoint saved. The test split is never used for training or model selection.

## Leaf detection and the whole-leaf scan
`backend/app/leaf.py` estimates the background colour from the photo's border, thresholds the difference (Otsu), cleans the mask and keeps the largest blob. The leaf is cropped onto a neutral grey background before classification. Works best on plain backgrounds; on cluttered field photos it may fail, in which case the app analyses the whole photo and says so. Set `LEAFGUARD_AUTOCROP=0` to disable. The heat-map hides 56x56 patches (49 positions, 28-px stride) and records the drop in the predicted class's score. Note: `evaluation/evaluate.py` measures accuracy on the plain centre-cropped test images, **without** the leaf-detection step, so its numbers do not cover that step.

## Honest limitations
The model only knows the 14 plants / 38 classes of PlantVillage. A photo of any other plant (for example a mango leaf) or a problem outside the training set (for example nutrient deficiency) will get a low-confidence guess among the known classes.
PlantVillage photos are lab-style (one leaf, plain background), so field photos will score much lower. The same leaves can appear in near-duplicate images across train/test splits in this dataset, which can inflate test accuracy. The model is closed-set: it always picks one of its classes, even for a non-leaf photo. Advice text is generic, not a diagnosis.

## Tests
`pytest -q` covers advice parsing (pure Python), the 503 "no model" path, a prediction through an untrained network (checks response shape, heat-map, history, analytics) and invalid-upload rejection. It does not measure accuracy.

## Docs
`docs/REPORT.md`, `docs/VIVA.md`, `docs/PRESENTATION.md`.
