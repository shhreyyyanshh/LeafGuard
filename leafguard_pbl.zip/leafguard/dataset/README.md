Put your extracted dataset here (folders = classes). See README.
