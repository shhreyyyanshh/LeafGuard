"""LeafGuard API: upload a leaf photo -> disease prediction + whole-leaf heat-map + advice."""
import base64, io, json, logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.concurrency import run_in_threadpool
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from PIL import Image, UnidentifiedImageError
from . import config, store

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("leafguard")
state = {"p": None, "error": None}


@asynccontextmanager
async def lifespan(app):
    store.init()
    if config.MODEL_PATH.exists():
        try:
            from .model import Predictor
            state["p"] = Predictor(config.MODEL_PATH)
            log.info("Model loaded: %s, %d classes, device=%s", state["p"].arch, len(state["p"].classes), state["p"].device)
        except Exception as e:
            state["error"] = str(e); log.exception("Could not load model")
    else:
        log.warning("No model at %s. Train one with scripts/train.py", config.MODEL_PATH)
    yield


app = FastAPI(title="LeafGuard", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])  # local use only


@app.get("/api/health")
def health():
    p = state["p"]
    return {"status": "ok", "model_loaded": p is not None, "model": p.arch if p else None, "device": p.device if p else None,
            "error": state["error"], "setup_hint": None if p else "Train a model: python scripts/train.py --data <dataset folder>"}


@app.post("/api/predict")
async def predict(file: UploadFile = File(...), heatmap: bool = True):
    if state["p"] is None:
        raise HTTPException(503, "No trained model yet. Follow the setup steps in the README (download dataset, then train).")
    if file.content_type not in config.ALLOWED_TYPES:
        raise HTTPException(415, "Please upload a JPG, PNG or WebP photo.")
    data = await file.read()
    if not data:
        raise HTTPException(400, "Empty file.")
    if len(data) > config.MAX_UPLOAD_MB * 1048576:
        raise HTTPException(413, f"File is larger than {config.MAX_UPLOAD_MB} MB.")
    try:
        Image.open(io.BytesIO(data)).verify()
        img = Image.open(io.BytesIO(data)).convert("RGB")
    except (UnidentifiedImageError, OSError):
        raise HTTPException(400, "That file is not a valid image.")
    r = await run_in_threadpool(state["p"].predict, img, 3, heatmap)
    t = img.copy(); t.thumbnail((128, 128)); b = io.BytesIO(); t.save(b, "JPEG", quality=80)
    r["id"] = store.log(file.filename or "upload", "data:image/jpeg;base64," + base64.b64encode(b.getvalue()).decode(), r)
    return r


@app.get("/api/classes")
def classes():
    from . import advice
    return [advice.parse(c) for c in (state["p"].classes if state["p"] else [])]


@app.get("/api/history")
def history():
    return store.history()


@app.delete("/api/history")
def clear():
    store.clear(); return {"cleared": True}


@app.get("/api/analytics")
def analytics():
    p = state["p"]
    return {"model": p.arch if p else None, "classes": len(p.classes) if p else 0, "val_accuracy": p.val_acc if p else None,
            "device": p.device if p else None, "status": "ready" if p else "no model", **store.stats()}


@app.get("/api/evaluation")
def evaluation():
    f = config.EVAL_DIR / "results.json"
    if not f.exists():
        raise HTTPException(404, "No evaluation yet. Run: python evaluation/evaluate.py")
    return json.loads(f.read_text())


config.EVAL_DIR.mkdir(exist_ok=True)
app.mount("/eval", StaticFiles(directory=config.EVAL_DIR), name="eval")


@app.get("/")
def home():
    return FileResponse(config.FRONTEND_DIR / "index.html")
