import os
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
MODEL_PATH = Path(os.getenv("LEAFGUARD_MODEL", ROOT / "models" / "leafguard.pt"))
DB_PATH = Path(os.getenv("LEAFGUARD_DB", ROOT / "database" / "leafguard.db"))
EVAL_DIR = ROOT / "evaluation"
FRONTEND_DIR = ROOT / "frontend"
MAX_UPLOAD_MB = int(os.getenv("LEAFGUARD_MAX_UPLOAD_MB", "8"))
ALLOWED_TYPES = {"image/jpeg", "image/png", "image/webp"}
LOW_CONFIDENCE = 0.60
AUTOCROP = os.getenv("LEAFGUARD_AUTOCROP", "1") != "0"  # set to 0 to analyse the whole photo without leaf detection
