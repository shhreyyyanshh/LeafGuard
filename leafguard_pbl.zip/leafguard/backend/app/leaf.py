"""Find the leaf in a photo and draw whole-leaf heat-maps. Pure NumPy + Pillow (no extra model to download).

Leaf finding: estimate the background colour from the photo's border, mark pixels that differ clearly from it (Otsu threshold),
clean up with morphology, keep the largest blob and fill holes. Works best with fairly plain backgrounds; if it cannot find a
convincing leaf it returns None and the caller analyses the whole photo instead."""
import io, base64
import numpy as np
from PIL import Image, ImageFilter

GRAY = (128, 128, 128)


def _otsu(v, bins=64):
    hist, edges = np.histogram(v, bins=bins)
    mids = (edges[:-1] + edges[1:]) / 2
    w0 = np.cumsum(hist); w1 = hist.sum() - w0
    m = np.cumsum(hist * mids)
    mu0 = m / np.maximum(w0, 1); mu1 = (m[-1] - m) / np.maximum(w1, 1)
    return float(edges[int(np.argmax(w0 * w1 * (mu0 - mu1) ** 2)) + 1])


def _flood(m, seen, y0, x0, h, w):
    stack, comp = [(y0, x0)], []
    seen[y0][x0] = True
    while stack:
        y, x = stack.pop(); comp.append((y, x))
        for ny, nx in ((y + 1, x), (y - 1, x), (y, x + 1), (y, x - 1)):
            if 0 <= ny < h and 0 <= nx < w and m[ny][nx] and not seen[ny][nx]:
                seen[ny][nx] = True; stack.append((ny, nx))
    return comp


def _largest(mask):
    h, w = mask.shape; m = mask.tolist(); seen = [[False] * w for _ in range(h)]; best = []
    for y, x in zip(*[a.tolist() for a in np.nonzero(mask)]):
        if not seen[y][x]:
            c = _flood(m, seen, y, x, h, w)
            if len(c) > len(best): best = c
    out = np.zeros(mask.shape, bool)
    if best:
        ys, xs = zip(*best); out[list(ys), list(xs)] = True
    return out


def _fill_holes(mask):
    h, w = mask.shape; inv = (~mask).tolist(); seen = [[False] * w for _ in range(h)]
    for y in range(h):
        for x in (0, w - 1):
            if inv[y][x] and not seen[y][x]: _flood(inv, seen, y, x, h, w)
    for x in range(w):
        for y in (0, h - 1):
            if inv[y][x] and not seen[y][x]: _flood(inv, seen, y, x, h, w)
    return mask | ~np.array(seen)  # background not reachable from the border = hole inside the leaf


def _segment(a):
    h, w, _ = a.shape; b = max(3, int(0.05 * min(h, w)))
    border = np.concatenate([a[:b].reshape(-1, 3), a[-b:].reshape(-1, 3), a[:, :b].reshape(-1, 3), a[:, -b:].reshape(-1, 3)])
    d = np.linalg.norm(a - np.median(border, 0), axis=2)
    if np.percentile(d, 99) < 30:
        return None  # nothing stands out from the background
    m = d > max(_otsu(d.ravel()), 25.0)
    mi = Image.fromarray((m * 255).astype(np.uint8))
    for f in (ImageFilter.MaxFilter, ImageFilter.MinFilter, ImageFilter.MinFilter, ImageFilter.MaxFilter):  # close, then open
        mi = mi.filter(f(5))
    m = _largest(np.asarray(mi) > 127)
    if not m.any():
        return None
    m = _fill_holes(m)
    return m if 0.03 <= m.mean() <= 0.92 else None


def detect(img, out_size=224, work=512):
    """Returns dict(base, mask, box, crop, mask_crop) or None. `crop` is a square, leaf-centred image with a neutral grey background."""
    img = img.convert("RGB")
    s = min(1.0, work / max(img.size))
    base = img.resize((max(1, round(img.width * s)), max(1, round(img.height * s))), Image.LANCZOS) if s < 1 else img.copy()
    small = base.copy(); small.thumbnail((192, 192), Image.BILINEAR)
    m = _segment(np.asarray(small, np.float32))
    if m is None:
        return None
    mask = np.asarray(Image.fromarray((m * 255).astype(np.uint8)).resize(base.size, Image.BILINEAR).filter(ImageFilter.GaussianBlur(1.5)), np.float32) / 255
    ys, xs = np.nonzero(mask > 0.5)
    if len(ys) == 0:
        return None
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    side = int(max(x1 - x0, y1 - y0) * 1.1) + 2
    ox, oy = int((x0 + x1) / 2 - side / 2), int((y0 + y1) / 2 - side / 2)
    a = np.asarray(base, np.float32)
    comp = Image.fromarray((a * mask[..., None] + np.array(GRAY, np.float32) * (1 - mask[..., None])).astype(np.uint8))
    crop = Image.new("RGB", (side, side), GRAY); crop.paste(comp, (-ox, -oy))
    mc = Image.new("L", (side, side), 0); mc.paste(Image.fromarray((mask * 255).astype(np.uint8)), (-ox, -oy))
    return {"base": base, "mask": mask, "box": (ox, oy, side), "crop": crop,
            "mask_crop": np.asarray(mc.resize((out_size, out_size), Image.BILINEAR), np.float32) / 255}


def occlusion_positions(S=224, p=56, stride=28):
    return [(i, j) for i in range(0, S - p + 1, stride) for j in range(0, S - p + 1, stride)]


def heat_from_drops(drops, pos, S, p, mask_c=None):
    """drops[k] = how much the score fell when patch k was hidden. Returns an SxS map in 0..1 covering the whole image."""
    acc = np.zeros((S, S), np.float32); cnt = np.zeros_like(acc)
    for (i, j), d in zip(pos, drops):
        acc[i:i + p, j:j + p] += d; cnt[i:i + p, j:j + p] += 1
    m = np.clip(acc / np.maximum(cnt, 1), 0, None)
    if mask_c is not None:
        m = m * mask_c
    ref = m[mask_c > 0.5] if mask_c is not None else m.ravel()
    scale = float(np.percentile(ref, 98)) if ref.size else 0.0
    if scale <= 1e-6:
        return np.zeros((S, S), np.float32)
    m = np.clip(m / scale, 0, 1) ** 0.8
    return np.asarray(Image.fromarray((m * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(4)), np.float32) / 255


def _jet(c):
    return np.stack([np.clip(1.5 - np.abs(4 * c - k), 0, 1) for k in (3, 2, 1)], -1)


def png_url(arr):
    buf = io.BytesIO(); Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)).save(buf, "PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def overlay(base, hm, info, alpha=0.6):
    """Colour only the leaf: blue = barely mattered, red = mattered a lot."""
    W, H = base.size; a = np.asarray(base, np.float32) / 255
    if info:
        ox, oy, side = info["box"]
        patch = np.asarray(Image.fromarray((hm * 255).astype(np.uint8)).resize((side, side), Image.BILINEAR), np.float32) / 255
        canvas = np.zeros((H, W), np.float32)
        ys, ye, xs, xe = max(oy, 0), min(oy + side, H), max(ox, 0), min(ox + side, W)
        canvas[ys:ye, xs:xe] = patch[ys - oy:ye - oy, xs - ox:xe - ox]
        mask = info["mask"]
    else:
        canvas = np.asarray(Image.fromarray((hm * 255).astype(np.uint8)).resize((W, H), Image.BILINEAR), np.float32) / 255
        mask = np.ones((H, W), np.float32)
    w = (alpha * mask)[..., None]
    return png_url((a * (1 - w) + _jet(canvas) * w) * 255)


def outline(base, mask):
    m = mask > 0.5; mi = Image.fromarray((m * 255).astype(np.uint8))
    edge = (np.asarray(mi.filter(ImageFilter.MaxFilter(5))) > 127) & ~(np.asarray(mi.filter(ImageFilter.MinFilter(5))) > 127)
    a = np.asarray(base, np.float32) * (0.35 + 0.65 * m[..., None]); a[edge] = (0, 230, 100)
    return png_url(a)
