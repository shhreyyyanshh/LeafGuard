import sqlite3, time
from . import config


def _c():
    config.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(config.DB_PATH); c.row_factory = sqlite3.Row; return c


def init():
    with _c() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS predictions(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, filename TEXT,
                     thumb TEXT, crop TEXT, condition TEXT, healthy INTEGER, confidence REAL, ms REAL)""")


def log(filename, thumb, r):
    with _c() as c:
        return c.execute("INSERT INTO predictions(ts,filename,thumb,crop,condition,healthy,confidence,ms) VALUES(?,?,?,?,?,?,?,?)",
                         (time.strftime("%Y-%m-%d %H:%M:%S"), filename, thumb, r["crop"], r["condition"], int(r["healthy"]), r["confidence"], r["time_ms"])).lastrowid


def history(n=40):
    with _c() as c:
        return [dict(r) for r in c.execute("SELECT * FROM predictions ORDER BY id DESC LIMIT ?", (n,))]


def clear():
    with _c() as c:
        c.execute("DELETE FROM predictions")


def stats():
    with _c() as c:
        n, avg, d = c.execute("SELECT COUNT(*), AVG(ms), SUM(1-healthy) FROM predictions").fetchone()
    return {"predictions": n, "avg_ms": round(avg, 1) if avg else None, "disease_found": int(d or 0)}
