"""Model building, checkpoint loading and prediction. torch is imported lazily.
Pipeline: find the leaf -> crop to it on a neutral background -> CNN -> top-k classes.
Heat-map: occlusion sensitivity. Hide each region of the leaf in turn and measure how much the predicted class's score drops,
so EVERY part of the leaf is examined (a single Grad-CAM blob only shows the strongest spot)."""
import time
import numpy as np
from PIL import Image
from . import advice, config, leaf


def build_model(arch, n_classes, pretrained=True):
    import torch.nn as nn
    import torchvision.models as tvm
    if arch == "mobilenet_v2":
        m = tvm.mobilenet_v2(weights=tvm.MobileNet_V2_Weights.IMAGENET1K_V1 if pretrained else None)
        m.classifier = nn.Sequential(nn.Dropout(0.2), nn.Linear(1280, n_classes))
    elif arch == "resnet18":
        m = tvm.resnet18(weights=tvm.ResNet18_Weights.IMAGENET1K_V1 if pretrained else None)
        m.fc = nn.Linear(512, n_classes)
    else:
        raise ValueError(f"Unknown architecture {arch}")
    return m


def head_params(model, arch):
    return model.classifier.parameters() if arch == "mobilenet_v2" else model.fc.parameters()


class Predictor:
    def __init__(self, path):
        import torch
        import torchvision.transforms as T
        self.torch = torch
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        ck = torch.load(path, map_location="cpu", weights_only=True)
        self.classes, self.arch, self.val_acc = ck["classes"], ck["arch"], ck.get("val_acc")
        self.model = build_model(self.arch, len(self.classes), pretrained=False)
        self.model.load_state_dict(ck["state_dict"])
        self.model.eval().to(self.device)
        self.size = ck.get("img_size", 224)
        self.pre = T.Compose([T.Resize(int(self.size * 1.14)), T.CenterCrop(self.size)])
        self.norm = T.Compose([T.ToTensor(), T.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

    def _scan(self, x, best, mask_c):
        """Occlusion sensitivity over the whole image, returns an SxS map in 0..1."""
        torch, S, p = self.torch, self.size, 56
        pos = leaf.occlusion_positions(S, p, 28)
        with torch.no_grad():
            base = self.model(x)[0, best].item()
            batch = x.repeat(len(pos), 1, 1, 1)
            for k, (i, j) in enumerate(pos):
                batch[k, :, i:i + p, j:j + p] = 0  # 0 = mean colour after normalisation
            scores = self.model(batch)[:, best].cpu().numpy()
        return leaf.heat_from_drops(base - scores, pos, S, p, mask_c)

    def predict(self, img: Image.Image, topk=3, cam=True):
        torch, t0 = self.torch, time.perf_counter()
        img = img.convert("RGB")
        info = leaf.detect(img, self.size) if config.AUTOCROP else None
        if info:
            base, crop, mask_c = info["base"], info["crop"].resize((self.size, self.size), Image.BICUBIC), info["mask_crop"]
        else:
            base = crop = self.pre(img); mask_c = None  # could not isolate a leaf: analyse the whole (centre-cropped) photo
        x = self.norm(crop).unsqueeze(0).to(self.device)
        with torch.no_grad():
            probs = torch.softmax(self.model(x), 1)[0].cpu().numpy()
        best = int(probs.argmax()); order = np.argsort(-probs)[:topk]
        top = [{**advice.parse(self.classes[i]), "confidence": round(float(probs[i]) * 100, 1)} for i in order]
        out = {**top[0], "top": top, "advice": advice.advise(self.classes[best]), "disclaimer": advice.DISCLAIMER,
               "low_confidence": bool(probs[best] < config.LOW_CONFIDENCE), "leaf_found": info is not None,
               "leaf_view": leaf.outline(base, info["mask"]) if info else None, "heatmap": None}
        if cam:
            out["heatmap"] = leaf.overlay(base, self._scan(x, best, mask_c), info)
        out["time_ms"] = round((time.perf_counter() - t0) * 1000, 1)
        return out
