"""Turn a PlantVillage-style class name into crop / condition / plain-language advice. Pure Python."""
import re

DISCLAIMER = "General information only, not a diagnosis. Confirm with a local agriculture extension officer or plant pathologist before treating."

_RULES = [  # (keywords, advice) checked in order
    (("virus", "curl", "mosaic"), "Viral diseases cannot be cured. Remove and destroy infected plants, control insect carriers such as whiteflies and aphids, and plant resistant varieties next season."),
    (("greening", "huanglongbing"), "Citrus greening has no cure. Remove infected trees, control the psyllid insect that spreads it, and report it to local agricultural authorities."),
    (("bacterial",), "Remove infected leaves, avoid working with wet plants, avoid overhead watering, rotate crops, and ask an expert about copper-based sprays."),
    (("mite",), "Spray leaves with water to dislodge mites, encourage natural predators, and consider miticide or neem/soap sprays after expert advice."),
    (("blight", "spot", "scab", "rust", "mildew", "mold", "rot", "scorch", "measles", "leaf_mold", "esca"),
     "Likely a fungal-type problem. Remove and dispose of affected leaves (do not compost), water at the base of the plant, improve spacing and airflow, and ask an expert about a suitable fungicide."),
]


def parse(label: str) -> dict:
    parts = label.split("___")
    crop = re.sub(r"\s*\(.*?\)", "", parts[0].replace("_", " ")).strip().title()
    cond = (parts[1] if len(parts) > 1 else "").replace("_", " ").strip().capitalize() or "Unknown"
    return {"label": label, "crop": crop, "condition": cond, "healthy": "healthy" in label.lower()}


def advise(label: str) -> str:
    if "healthy" in label.lower():
        return "No disease detected. Keep up regular watering, good spacing and routine checks."
    low = label.lower()
    for keys, text in _RULES:
        if any(k in low for k in keys):
            return text
    return "Isolate the plant, remove badly affected leaves, and consult a local agriculture expert."
