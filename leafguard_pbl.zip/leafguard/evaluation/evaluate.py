"""Evaluate the trained model on the held-out test split saved by train.py. All numbers are measured, none hard-coded."""
import json, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
from PIL import Image
from backend.app import config
from backend.app.model import Predictor

if not config.MODEL_PATH.exists() or not (config.MODEL_PATH.parent / "split.json").exists():
    sys.exit("Train first: python scripts/train.py --data <dataset folder>")
sp = json.loads((config.MODEL_PATH.parent / "split.json").read_text())
P = Predictor(config.MODEL_PATH); torch = P.torch; n = len(P.classes)
y_true, y_pred, conf = np.array(sp["labels"]), [], []
for i in range(0, len(sp["test"]), 64):
    xs = torch.stack([P.norm(P.pre(Image.open(f).convert("RGB"))) for f in sp["test"][i:i + 64]]).to(P.device)
    with torch.no_grad():
        pr = torch.softmax(P.model(xs), 1).cpu().numpy()
    y_pred += pr.argmax(1).tolist(); conf += pr.max(1).tolist()
y_pred = np.array(y_pred)
cm = np.zeros((n, n), int)
for t, p in zip(y_true, y_pred): cm[t, p] += 1
tp = np.diag(cm); prec = tp / np.maximum(cm.sum(0), 1); rec = tp / np.maximum(cm.sum(1), 1); f1 = 2 * prec * rec / np.maximum(prec + rec, 1e-12)
per = {P.classes[i]: {"precision": round(float(prec[i]), 4), "recall": round(float(rec[i]), 4), "f1": round(float(f1[i]), 4), "support": int(cm[i].sum())} for i in range(n)}
conf_pairs = sorted([(int(cm[i, j]), P.classes[i], P.classes[j]) for i in range(n) for j in range(n) if i != j and cm[i, j]], reverse=True)[:10]
lat = []
for f in sp["test"][:20]:
    img = Image.open(f).convert("RGB"); t = time.perf_counter(); P.predict(img, 3, cam=False); lat.append((time.perf_counter() - t) * 1000)
res = {"model": P.arch, "device": P.device, "n_test": int(len(y_true)), "accuracy": round(float((y_true == y_pred).mean()), 4),
       "macro_f1": round(float(f1.mean()), 4), "mean_confidence": round(float(np.mean(conf)), 4), "latency_ms_mean": round(float(np.mean(lat)), 1),
       "per_class": per, "top_confusions": [{"count": c, "true": a, "predicted": b} for c, a, b in conf_pairs]}
(config.EVAL_DIR / "results.json").write_text(json.dumps(res, indent=2))
try:
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(10, 9)); ax.imshow(cm / np.maximum(cm.sum(1, keepdims=True), 1), cmap="Greens")
    ax.set_title("Confusion matrix (row-normalised, test set)"); ax.set_xlabel("Predicted"); ax.set_ylabel("True")
    if n <= 40: ax.set_xticks(range(n)); ax.set_yticks(range(n)); ax.set_xticklabels(range(n), fontsize=6); ax.set_yticklabels(range(n), fontsize=6)
    fig.tight_layout(); fig.savefig(config.EVAL_DIR / "confusion_matrix.png", dpi=130)
    h = config.MODEL_PATH.parent / "history.json"
    if h.exists():
        H = json.loads(h.read_text()); fig, ax = plt.subplots(figsize=(6, 3.5))
        ax.plot([e["train_acc"] for e in H], label="train acc"); ax.plot([e["val_acc"] for e in H], label="val acc"); ax.set_xlabel("epoch"); ax.legend(); fig.tight_layout(); fig.savefig(config.EVAL_DIR / "training_curve.png", dpi=130)
except ImportError:
    pass
print({k: res[k] for k in ("model", "device", "n_test", "accuracy", "macro_f1", "latency_ms_mean")})
