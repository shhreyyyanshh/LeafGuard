# LeafGuard — Technical Report (skeleton; **[RUN]** = fill from your own results)
1. **Abstract** — CNN-based plant disease classifier with occlusion sensitivity explanations and a web interface. **[RUN]** headline accuracy / macro-F1.
2. **Problem** — Crop diseases cause major yield losses; early identification needs expertise that many farmers lack.
3. **Objectives** — Train a transfer-learning classifier; explain predictions; serve through an easy web app; evaluate honestly.
4. **Existing vs proposed** — Manual inspection / expert visits vs instant photo-based screening with visual explanation.
5. **Methodology** — Data → resize/augment → pretrained CNN + new head → two-stage fine-tuning → evaluation → deployment (see README).
6. **DL concepts** — CNNs, transfer learning, fine-tuning, data augmentation, softmax/cross-entropy, label smoothing, occlusion sensitivity, precision/recall/F1, confusion matrix.
7. **Dataset** — PlantVillage (see README for sources and licence). **[RUN]** number of classes and images used.
8. **Results** — **[RUN]** `evaluation/results.json`, confusion matrix, training curve, top confusions, latency.
9. **Limitations** — see README. 10. **Future scope** — field-image training, out-of-distribution detection, severity estimation, mobile/offline deployment (TFLite/ONNX), multilingual advice.
11. **References** — Hughes & Salathé 2015 (*An open access repository of images on plant health*); Mohanty et al. 2016 (*Using deep learning for image-based plant disease detection*); Sandler et al. 2018 (*MobileNetV2*); He et al. 2016 (*ResNet*); Selvaraju et al. 2017 (*occlusion sensitivity*).
