# Viva questions
1. **Why transfer learning?** ImageNet features (edges, textures) transfer to leaves; needs less data and time than training from scratch.
2. **Why freeze the backbone first?** The new head is random; training it first avoids large gradients wrecking pretrained weights.
3. **What is occlusion sensitivity?** Hide each region of the leaf in turn and measure how much the predicted class's score drops; bigger drops mean more important regions. It covers the whole leaf, unlike a single Grad-CAM blob, but costs 49 extra forward passes.
4. **Why macro-F1 as well as accuracy?** Treats every class equally; shows weak classes that overall accuracy hides.
5. **Why a separate test set?** Validation picks the checkpoint; only an untouched test set gives an unbiased estimate.
6. **Why might accuracy be inflated?** PlantVillage has near-duplicate images and uniform backgrounds; field photos differ.
7. **What happens with a non-leaf photo?** Softmax forces a choice among known classes; low confidence is the only hint. Fix: add an "other" class or out-of-distribution detection.
8. **Why MobileNetV2?** Small and fast on CPU; ResNet18 is available via `--arch`. Compare using your measured results.
9. **What does label smoothing do?** Softens one-hot targets to reduce over-confidence.
10. **Is the advice medical-grade?** No; it is generic guidance with a disclaimer.
