@echo off
REM LeafGuard launcher for Windows. Double-click. Needs internet on the first run.
cd /d "%~dp0"
where python >nul 2>nul || (echo Install Python 3.10+ from python.org and tick Add to PATH, then run again. & pause & exit /b 1)
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
if not exist .venv\.installed (
  pip install -r requirements.txt || (echo Install failed. & pause & exit /b 1)
  echo done > .venv\.installed
)
python scripts\check_setup.py
if errorlevel 11 goto train
if errorlevel 10 goto download
goto start
:download
python scripts\download_dataset.py --per-class 200
if errorlevel 1 (echo Dataset download did not finish. Just run this file again to resume. & pause & exit /b 1)
:train
python scripts\train.py --data dataset --epochs 4 --max-per-class 300
if errorlevel 1 (echo Training failed. & pause & exit /b 1)
python evaluation\evaluate.py
:start
start "" http://localhost:8000
uvicorn backend.app.main:app --port 8000
pause
